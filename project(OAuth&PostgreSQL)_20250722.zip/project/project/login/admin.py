from django.contrib import admin

# Register your models here.f
from .import models
admin.site.register(models.User)
